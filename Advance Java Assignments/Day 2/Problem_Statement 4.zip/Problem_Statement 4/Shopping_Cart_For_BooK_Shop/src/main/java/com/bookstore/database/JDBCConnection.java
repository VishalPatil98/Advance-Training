package com.bookstore.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCConnection {

	private static Connection con;
	
	public static Connection getConnection() {
		try {
			if(con==null) {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore",
						"root","vishal@12345");
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return con;
	}
	
}
