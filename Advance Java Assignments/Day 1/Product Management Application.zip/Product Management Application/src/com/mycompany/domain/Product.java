package com.mycompany.domain;
public class Product 
{
	String Product_id;
	String Product_name;
	double Product_price;
	public String getProduct_id() 
	{
		return Product_id;
	}
	public void setProduct_id(String product_id) 
	{
		Product_id = product_id;
	}	
	public String getProduct_name() 
	{
		return Product_name;
	}
	public void setProduct_name(String product_name) 
	{
		Product_name = product_name;
	}
	public double getProduct_price()
	{
		return Product_price;
	}
	public void setProduct_price(double product_price) 
	{
		Product_price = product_price;
	}
}