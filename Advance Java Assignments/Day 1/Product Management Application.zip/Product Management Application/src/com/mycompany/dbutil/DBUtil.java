package com.mycompany.dbutil;
import java.sql.*;
public class DBUtil 
{
	public static Connection getConnect()
	{
		Connection connection=null;
		try
		{
			String driver="com.mysql.cj.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/productdb";
			String username="root";
			String password="vishal@12345";
			//Loading Driver
			Class.forName(driver);
			//passing parameters
			connection=DriverManager.getConnection(url, username, password);
		}
		catch (Exception e)
		{
			System.out.println("Error Occured");
			e.printStackTrace();
		}
		return connection;
	}
}
