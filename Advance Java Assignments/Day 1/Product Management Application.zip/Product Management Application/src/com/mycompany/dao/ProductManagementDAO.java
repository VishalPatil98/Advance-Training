package com.mycompany.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;
public class ProductManagementDAO
{
	// Method to get All Products
	public static void viewAll(Product p) throws Exception
	{
		Connection con=DBUtil.getConnect();
		PreparedStatement ps=con.prepareStatement("select * from product");
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			System.out.println("\n Product Id: "+rs.getString(1) 
			+ "\n Product Name: " + rs.getString(2) 
			+ "\n Product Price: " + rs.getDouble(3));	
		}
		con.close();
	}
	// Method For adding new product
	public static void add(Product p) throws Exception
	{
		Connection con=DBUtil.getConnect();
		String query="insert into product(product_id,product_name,product_price) values(?,?,?)";
		PreparedStatement stmt=con.prepareStatement(query);
		stmt.setString(1, p.getProduct_id());
		stmt.setString(2, p.getProduct_name());
		stmt.setDouble(3, p.getProduct_price());
		int rs=stmt.executeUpdate();
		if(rs>0)
		{
			System.out.println("Data Saved");
		}
		else
		{
			System.out.println("Data Not Saved");
		}
		con.close();
	}
	// Method for updating product
	public static void update(Product p) throws Exception
	{
		Connection con=DBUtil.getConnect();
		String query="update product set product_name=?,product_price=? where product_id=?";
		PreparedStatement stmt=con.prepareStatement(query);
		stmt.setString(1, p.getProduct_name());
		stmt.setDouble(2, p.getProduct_price());
		stmt.setString(3, p.getProduct_id());
		int rs=stmt.executeUpdate();
		if(rs>0)
		{
			System.out.println("Data Updated For Product ID: "+p.getProduct_id());
		}
		else
		{
			System.out.println("Product ID Not Found");
		}
		con.close();
	}
	// Method to delete Product
	public static void delete(Product p) throws Exception
	{
		Connection con=DBUtil.getConnect();
		String query="delete from product where product_id=?";
		PreparedStatement stmt=con.prepareStatement(query);
		stmt.setString(1, p.getProduct_id());
		int rs=stmt.executeUpdate();
		if(rs>0)
		{
			System.out.println("Data Deleted For Product ID: "+p.getProduct_id());
		}
		else
		{
			System.out.println("Product ID Not Found");
		}
		con.close();
	}
	// Method For search specific Product
	public static void viewByID(Product p) throws Exception
	{
		Connection con=DBUtil.getConnect();
		PreparedStatement ps=con.prepareStatement("select * from product where product_id=?");
		ps.setString(1, p.getProduct_id());
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			System.out.println("\n Product Id: "+rs.getString(1) 
			+ "\n Product Name: " + rs.getString(2) 
			+ "\n Product Price: " + rs.getDouble(3));	
		}
		con.close();
	}
}