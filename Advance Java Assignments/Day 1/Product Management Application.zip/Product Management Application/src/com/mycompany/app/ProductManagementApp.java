package com.mycompany.app;
import java.util.Scanner;
import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;
public class ProductManagementApp 
{
	Scanner sc=new Scanner(System.in);
	Product p=new Product();
	ProductManagementDAO prod=new ProductManagementDAO();
	public void insert() throws Exception
	{
		System.out.println("******** ADD PRODUCT ******** ");
		System.out.println("------------------------------");
		System.out.println("Enter Product Id:");
		p.setProduct_id(sc.next());
		System.out.println("------------------------------");
		System.out.println("Enter Product name");
		p.setProduct_name(sc.next());
		System.out.println("------------------------------");
		System.out.println("Enter Product price");
		p.setProduct_price(sc.nextDouble());
		System.out.println("------------------------------");
		prod.add(p);	
	}
	public void modify() throws Exception
	{
		System.out.println("******** UPDATE PRODUCT ******** ");
		System.out.println("------------------------------");
		System.out.println("Enter Product Id which you have to update :");
		p.setProduct_id(sc.next());
		System.out.println("------------------------------");
		System.out.println("Enter Product name");
		p.setProduct_name(sc.next());
		System.out.println("------------------------------");
		System.out.println("Enter Product price");
		p.setProduct_price(sc.nextDouble());
		System.out.println("------------------------------");
		prod.update(p);	
	}
	public void remove() throws Exception
	{
		System.out.println("******** DELETE PRODUCT ******** ");
		System.out.println("------------------------------");
		System.out.println("Enter Product Id which you have to delete :");
		p.setProduct_id(sc.next());	
		System.out.println("------------------------------");
		prod.delete(p);
	}
	public void getAll() throws Exception
	{
		prod.viewAll(p);
	}
	public void getByID() throws Exception
	{
		System.out.println("Enter Product Id To Search:");
		p.setProduct_id(sc.next());
		prod.viewByID(p);
	}	
	public static void main(String[] args) throws Exception
	{
		ProductManagementApp pr=new ProductManagementApp();
		Scanner sc = new Scanner(System.in);
		while (true) 
		{
			System.out.println("----------------------------------------");
			System.out.println("A. View Products");
			System.out.println("B. Add Product");
			System.out.println("C. Update Product");
			System.out.println("D. Delete Product");
			System.out.println("E. Search Product");
			System.out.println("F. Exit");
			System.out.println("=========================");
			System.out.println("Enter an option");
			System.out.println("=========================");
			String ch = sc.next();
			switch (ch) 
			{
			case "A":
				pr.getAll();
				break;
			case "B":
				pr.insert();
				break;
			case "C":
				pr.modify();
				break;
			case "D":
				pr.remove();
				break;
			case "E":
				pr.getByID();
				break;
			case "F":
				System.out.println("*******************Thank You!!********************");
				System.exit(0);
				break;
			default:
			}
		}
	}
}
