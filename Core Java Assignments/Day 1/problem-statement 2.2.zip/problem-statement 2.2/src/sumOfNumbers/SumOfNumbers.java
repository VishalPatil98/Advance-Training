package sumOfNumbers;
import java.util.Scanner;
public class SumOfNumbers 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number 1:");
		int num1=sc.nextInt();
		System.out.println("Enter Number 2:");
		int num2=sc.nextInt();
		int i=0 ,n=15;
		int first_num=num1;
		int second_num=num2;
		while(i<n)
		{
			System.out.println(first_num+" ");
			int next_num=first_num+second_num;
			first_num=second_num;
			second_num=next_num;
			i++;
		}	
	}
}