package arrayOperation;

public class ArrayOperation 
{
	public static void main(String[] args) 
	{
		int[] arr=new int[] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0,0};
		int sum=0;
		int avg=0;
		int temp;
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		arr[15]=sum;
		System.out.println("Sum of 0 to 14 indexes is Stored at 15th location");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		avg=sum/arr.length;
		arr[16]=avg;
		System.out.println("Average is Stored at 16th location");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		 for(int i=0;i<arr.length;i++) 
		 {
			  for(int j=i+1;j<arr.length;j++) 
			  {
				  if(arr[i]>arr[j]) 
				  {
					  temp=arr[i];
					  arr[i]=arr[j];
					  arr[j]=temp;
				  }
			 }
		 }
		 System.out.println("Smallest Element in array is:"+arr[0]);	 
	}
}
