package fileOperation;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class FileOperations 
{
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in); 
		FileReader filereader = null; 		        
		FileWriter filewriter = null; 
		try
		{ 
			System.out.println("Enter a source file which exists");       
		    String f1=scan.next(); 		           
		    filereader = new FileReader(f1); 
		    System.out.println("Enter a destination file"); 		            
		    String f2=scan.next();
		    File f3= new File(f2); 
		    if(!f3.exists()) 
		    { 
		    	filewriter = new FileWriter(f2); 
		    	f3.createNewFile(); 
		    	int c = filereader.read(); 
		    	while(c!=-1) 
		    	{ 
		    		filewriter.write(c); 
		    		c = filereader.read(); 
		    	} 		                
		    	System.out.println("File copied successfully"); 		            
		    }
		    else
		    { 	            	
		    	filewriter = new FileWriter(f2); 	    	
		    	System.out.println("Do you want to overwrite? enter 'yes' or 'no'..."); 
		    	char ans = scan.next().charAt(0);
		    	if(ans=='N'||ans=='n') 
		    	{ 
		    		System.out.println("Could not enter data"); 
		    	}
		    	else
		    	{ 
		    		int c = filereader.read(); 
		    		while(c!=-1) 
		    		{ 
		    			filewriter.write(c); 
		    			c = filereader.read(); 
		    		} 
		    		System.out.println("File updated successfully"); 
		    	} 
		    } 
		} 
		catch(IOException e) 
		{ 
			System.out.println("File Not Found"); 
		}
		finally 
		{ 
			close(filereader); 
			close(filewriter); 
		} 
	} 
	public static void close(Closeable stream) 
	{ 
		try
		{ 
			if (stream != null)
			{ 
				stream.close(); 
			} 
		}
		catch(IOException e)
		{ 
			System.out.println(e);
		}
	}
}