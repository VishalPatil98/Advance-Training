package palindrome;

import java.util.Scanner;

public class Palindrome 
{
	public static void Length(String str)
	{
		System.out.println("The Length of String is:"+ str.length());
	}
	public static void Upper(String str)
	{
		System.out.println("The Input String is:"+str);
		System.out.println("Input String in Uppercase:"+str.toUpperCase());
	}
	public static void Palidrome(String str)
	{
		String str1="";
		int length=str.length();
		for ( int i = length - 1; i >= 0; i-- )
		{
	         str1 = str1 + str.charAt(i);
		}
	    if (str.equals(str1))
	    {
	      System.out.println(str+" is a palindrome");
	    }
	    else 
	    {
	     System.out.println(str+" is not a palindrome");
	    }
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String:");
		String str=sc.next();
		Palindrome p=new Palindrome();
		p.Length(str);
		p.Upper(str);
		p.Palidrome(str);		
	}
}