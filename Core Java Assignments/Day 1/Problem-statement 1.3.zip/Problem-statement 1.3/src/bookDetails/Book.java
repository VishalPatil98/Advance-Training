package bookDetails;
public class Book 
{
	private String title;
	private double price;
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title) 
	{
		this.title = title;
	}
	public double getPrice() 
	{
		return price;
	}
	public void setPrice(double price) 
	{
		this.price = price;
	}
	public Book(String title, double price) 
	{
		this.title = title;
		this.price = price;
	}
	public void display()
	{
	     System.out.println("book_title: "+this.title);
	     System.out.println("book_price: "+this.price);
	}
}