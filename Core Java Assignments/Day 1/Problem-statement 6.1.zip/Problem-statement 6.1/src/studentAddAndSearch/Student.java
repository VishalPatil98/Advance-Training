package studentAddAndSearch;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Student 
{
	static void solve()
	{
	    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	    ArrayList<String> Names=new ArrayList<String>();
	    int option=-1;
	    System.out.println("-----Student Records------");
	    try
	    {
	    	while(option!=3)
	    	{
	    		System.out.println("\n Enter the option "
	    				+ "\n 1.Add a name "
	    				+ "\n 2.Check a name "
	    				+ "\n 3.Exit");
	    		option=Integer.parseInt(br.readLine());
	    		switch(option)
	    		{
	    		case 1:
	            {
	                System.out.println("Enter name of student:");      
	                String temp=br.readLine();	                
	                Names.add(temp);	                
	                System.out.println(temp+" added to List");     
	                break;
	            }
	            case 2:
	            {
	                System.out.println("Enter the name to he searched :");   
	                String temp=br.readLine();	                
	                if(Names.indexOf(temp)>=0)
	                {
	                	System.out.println(temp+"  is present in List");	
	                }                    
	                else 
	                {
	                	System.out.println(temp+"  is not found in List");	                	
	                }
	                break;
	                }
	    		}
	    	}
	   }
	    catch(Exception e)
	    {
	        System.out.println("error occured"+e);
	    }
	}
	public static void main(String[] args) 
	{
		solve();
	}
}