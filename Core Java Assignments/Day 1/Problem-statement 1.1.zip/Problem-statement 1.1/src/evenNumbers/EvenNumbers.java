/* 1.1 Write a program to list all, even numbers less than or equal to the number n. 
 * Take the value of n as input from the user. */
package evenNumbers;
import java.util.Scanner;
public class EvenNumbers 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number :");
		int n=sc.nextInt();
		System.out.println("Even Numbers From 1 to"+n+"are :");
		for(int i=1; i<=n; i++)
		{
			if(i%2==0)
			{
				System.out.print(i+" ");
			}	
		}		
	}
}