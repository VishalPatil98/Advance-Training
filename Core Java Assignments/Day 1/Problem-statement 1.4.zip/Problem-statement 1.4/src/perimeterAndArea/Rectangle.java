package perimeterAndArea;
import java.util.Scanner;
public class Rectangle 
{
	float length=1;
	float width=1;
	public Rectangle(float length, float width) 
	{
		this.length = length;
		this.width = width;
	}
	public float getLength()
	{
		return length;		
	}
	public void setLength(float length) 
	{
		if(getLength()<0 || getLength()>20)
		{
			System.out.println("Please Enter Length Between 0 to 20");
		}
		else
		{
			
			this.length = length;
			Area(length, length);
			Perimeter(length, length);
		}			
	}
	public float getWidth() 
	{
		return width;
	}
	public void setWidth(float width) 
	{
		this.width = width;
	}
	public static void Perimeter(float length, float width)
	{
		System.out.println("Length of rectangle is:" +length);
		System.out.println("Width of rectangle is:"+width);
		float perimeter=2*(length+width);
		System.out.println("Perimeter of Rectangle is :"+perimeter);
	}
	public static void Area(float length, float width)
	{
		float area=(length*width);
		System.out.println("Area of Rectangle is :"+area);
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Length :");
		float l=sc.nextFloat();
		System.out.println("Enter Width :");
		float w=sc.nextFloat();
		Rectangle r1=new Rectangle(l, w);
		r1.setLength(l);
		r1.setWidth(w);		
	}
}
