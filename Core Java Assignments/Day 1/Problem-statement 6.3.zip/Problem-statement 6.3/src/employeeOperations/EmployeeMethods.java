package employeeOperations;

import java.util.LinkedList;

public class EmployeeMethods 
{
	public static LinkedList<Employee> addInput()
	{
		Employee e1=new Employee(101,"Vishal","Patil");
		Employee e2=new Employee(102,"Ashwin","Chavan");
		Employee e3=new Employee(103,"Vijay","Patel");
		LinkedList<Employee> s = new LinkedList<Employee>();
		s.add(e1);
		s.add(e2);
		s.add(e3);
		return s;
	}
	public static void display(LinkedList<Employee> s)
	{
		for(Employee e:s)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}	
	}
	public static void main(String[]args) 
	{
		LinkedList<Employee> e=addInput();
		display(e);
	}

}
